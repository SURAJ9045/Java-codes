import java.sql.*;
import java.util.Scanner;

public class Employee {

    private static final String URL = "jdbc:mysql://localhost:3306/testdb";
    private static final String USER = "root";
    private static final String PASSWORD = "suraj1";

    public static void main(String[] args) {
        try (Scanner scanner = new Scanner(System.in)) {
            Class.forName("com.mysql.cj.jdbc.Driver");
            
            try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD)) {
                System.out.println("Connected to the database successfully!");

                createEmployeeTable(connection);

                int choice;
                do {
                    displayMenu();
                    System.out.print("Enter your choice: ");
                    choice = scanner.nextInt();
                    scanner.nextLine(); 

                    switch (choice) {
                        case 1:
                            addEmployee(connection, scanner);
                            break;
                        case 2:
                            viewAllEmployees(connection);
                            break;
                        case 3:
                            updateEmployeeEmail(connection, scanner);
                            break;
                        case 4:
                            deleteEmployee(connection, scanner);
                            break;
                        case 5:
                            System.out.println("Exiting Employee Management System. Goodbye!");
                            break;
                        default:
                            System.out.println("Invalid choice. Please try again.");
                    }
                    System.out.println("\n------------------------------------\n");
                } while (choice != 5);

            } 
            System.out.println("Database connection closed.");
        } catch (SQLException e) {
            System.err.println("SQL Error occurred: " + e.getMessage());
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            System.err.println("JDBC Driver not found: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("An unexpected error occurred: " + e.getMessage());
            e.printStackTrace();
        }
    }


    private static void displayMenu() {
        System.out.println("Employee Management System");
        System.out.println("1. Add Employee");
        System.out.println("2. View All Employees");
        System.out.println("3. Update Employee Email");
        System.out.println("4. Delete Employee");
        System.out.println("5. Exit");
    }

   
    private static void createEmployeeTable(Connection connection) throws SQLException {
        String createTableSQL = "CREATE TABLE IF NOT EXISTS employees ("
                + "id INT AUTO_INCREMENT PRIMARY KEY, " 
                + "name VARCHAR(100) NOT NULL, "
                + "position VARCHAR(100) NOT NULL, "
                + "email VARCHAR(100) UNIQUE NOT NULL, "
                + "salary DECIMAL(10, 2) NOT NULL)";
        
        try (Statement stmt = connection.createStatement()) {
            stmt.execute(createTableSQL);
            System.out.println("Table 'employees' checked/created successfully!");
        }
    }

   
    private static void addEmployee(Connection connection, Scanner scanner) {
        System.out.print("Enter Employee Name: ");
        String name = scanner.nextLine();
        System.out.print("Enter Employee Position: ");
        String position = scanner.nextLine();
        System.out.print("Enter Employee Email: ");
        String email = scanner.nextLine();
        System.out.print("Enter Employee Salary: ");
        double salary = scanner.nextDouble();
        scanner.nextLine(); 

        String insertSQL = "INSERT INTO employees (name, position, email, salary) VALUES (?, ?, ?, ?)";
        
        try (PreparedStatement pstmt = connection.prepareStatement(insertSQL)) {
            pstmt.setString(1, name);
            pstmt.setString(2, position);
            pstmt.setString(3, email);
            pstmt.setDouble(4, salary);
            
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Employee '" + name + "' added successfully!");
            } else {
                System.out.println("Failed to add employee.");
            }
        } catch (SQLIntegrityConstraintViolationException e) {
            System.err.println("Error: An employee with this email already exists. Please use a unique email.");
        } catch (SQLException e) {
            System.err.println("Error adding employee: " + e.getMessage());
            e.printStackTrace();
        }
    }

 
    private static void viewAllEmployees(Connection connection) throws SQLException {
        String selectSQL = "SELECT id, name, position, email, salary FROM employees";
        
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(selectSQL)) {
            System.out.println("--- All Employees ---");
            boolean hasData = false;
            while (rs.next()) {
                hasData = true;
                System.out.printf("ID: %d, Name: %s, Position: %s, Email: %s, Salary: %.2f%n",
                                  rs.getInt("id"),
                                  rs.getString("name"),
                                  rs.getString("position"),
                                  rs.getString("email"),
                                  rs.getDouble("salary"));
            }
            if (!hasData) {
                System.out.println("No employees found in the system.");
            }
        }
    }

 
    private static void updateEmployeeEmail(Connection connection, Scanner scanner) {
        System.out.print("Enter Employee ID to update email: ");
        int id = scanner.nextInt();
        scanner.nextLine(); 

        System.out.print("Enter new Email Address: ");
        String newEmail = scanner.nextLine();

        String updateSQL = "UPDATE employees SET email = ? WHERE id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(updateSQL)) {
            pstmt.setString(1, newEmail);
            pstmt.setInt(2, id);
            
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Employee ID " + id + "'s email updated successfully!");
            } else {
                System.out.println("No employee found with ID: " + id + ". Email not updated.");
            }
        } catch (SQLIntegrityConstraintViolationException e) {
            System.err.println("Error: The new email '" + newEmail + "' is already used by another employee.");
        } catch (SQLException e) {
            System.err.println("Error updating employee email: " + e.getMessage());
            e.printStackTrace();
        }
    }

   
    private static void deleteEmployee(Connection connection, Scanner scanner) {
        System.out.print("Enter Employee ID to delete: ");
        int id = scanner.nextInt();
        scanner.nextLine(); 

        String deleteSQL = "DELETE FROM employees WHERE id = ?";
        
        try (PreparedStatement pstmt = connection.prepareStatement(deleteSQL)) {
            pstmt.setInt(1, id);
            
            int rowsAffected = pstmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Employee with ID " + id + " deleted successfully!");
            } else {
                System.out.println("No employee found with ID: " + id + ". Deletion failed.");
            }
        } catch (SQLException e) {
            System.err.println("Error deleting employee: " + e.getMessage());
            e.printStackTrace();
 }
}
}